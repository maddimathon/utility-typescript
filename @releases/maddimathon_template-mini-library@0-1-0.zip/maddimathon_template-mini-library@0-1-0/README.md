# Mini-Library Template <!--CURRENT_VERSION--><!--/CURRENT_VERSION-->

<!--CURRENT_DESC-->
<!--/CURRENT_DESC-->

This README includes information relevant to this template, but it’s intended to
be used as a template for the end library’s README rather than a resource about this
template.  The only exception is this paragraph and the 
[Search \& Replace](#search--replace) section below, which is used to set up the
template. If you’re a developer who isn’t me and wants to use this template, you
probably want to fork it first and tailor it more to your tastes and needs.
**Don’t forget to review and edit this file as you set up the template.**

## Template Setup --- Search & Replace

Assume all those below are case-sensitive unless otherwise stated.

| Search                               | Replace                 | Notes                                         |
| :----------------------------------- | :---------------------- | :-------------------------------------------- |
| `@maddimathon/template-mini-library` | *package name*          | lower-case letters, numbers, and hyphens only |
| `template-mini-library`              | *github repo name*      | check as you go; used in urls                 |
| `Mini-Library Template`              | *readable package name* | title case                                    |


## Development

This library is maintained by [Maddi Mathon](https://www.maddimathon.com).


### Coding Practices